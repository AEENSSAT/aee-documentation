### Dossiers ###
JPEG -> Exports matriciels JPEG
PNG  -> Exports matriciels PNG
SVG  -> Exports Vectoriels SVG
AI   -> Exports Vectoriels Illustrator

### Nommage des images ###

LogoAEE-***x***-***.jpg/png/


***x*** -> Dimensions de l'image
-*** -> Qualit� de l'image (Pour les JPEG uniquement)